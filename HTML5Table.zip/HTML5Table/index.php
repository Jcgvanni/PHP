<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <h1>Squares and Cubes</h1>
    <body>
        
        <?php      
        $square;
        $cube;
        echo "<table border = '4' cellpadding='10'>";
        echo "<tr> <th><font size='8'>Number</th>"
                . " <th><font size='8'>Square</th> "
                . "<th><font size='8'>Cube</th> </tr>";
        // put your code here
        for($number = 0; $number <= 5; $number++){
            echo    "<tr>";                      
            $square = pow($number, 2);
            $cube = pow($number, 3);
            echo "<td><font size='6'>$number</td>"
                 . " <td><font size='6'>$square</td>"
                 . " <td><font size='6'>$cube</td> </tr>";                               
        }
        echo "</table>";     
        ?>
    </body>
</html>

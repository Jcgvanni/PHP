<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Triangles</title>
    </head>
      <h1>Triangles</h1>
    <body>
        <?php
        echo "<h3 style= 'color:orange'>First Triangle</h3>";
        for($row = 1; $row <= 10; $row++){
            for($column = 1; $column <= $row; $column++){
                echo "*";                            
            }
            echo "<br>";
        }
        echo"<hr>";
        
        echo "<h3 style= 'color:red'>Second Triangle</h3>";
        for($row = 10; $row >= 1; $row--){
            for($column = 1; $column <= $row; $column++){
                echo "*";                  
            }
            echo "<br>";
        }
         echo"<hr>";
         
        echo "<h3 style= 'color:blue'>Third Triangle</h3>";
        for($row = 10; $row >= 1; $row--){
            for($column = 10; $column > $row; $column--){
                echo "&nbsp;&nbsp;";             
            }
            for($reverse = 1; $reverse <= $row ; $reverse++){
                  echo "*";
            }
          echo "<br>";
        }
        echo"<hr>";
        
        echo "<h3 style= 'color:green'>Fourth Triangle</h3>";
        for($row = 10; $row >= 1; $row--){
            for($column = 1; $column < $row; $column++){
                echo "&nbsp;&nbsp;";                                     
            }
            for($reverse = 10; $reverse >= $row ; $reverse--){
                 echo "*";
            }
            echo "<br>";
        }       
        echo"<hr>";  
        
        ?>
    </body>
</html>

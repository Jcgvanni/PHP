<?php
// variables
$product_description = filter_input(INPUT_POST, 'product_description');
$list_price = filter_input(INPUT_POST, 'list_price', FILTER_VALIDATE_FLOAT);
$discount_percent = filter_input(INPUT_POST, 'discount_percent', FILTER_VALIDATE_INT);
$tax_rate = 8;

//calculate discount
$discount = $list_price * $discount_percent * .01;
$discount_price = $list_price - $discount;

//calculate tax
$tax_amount = $discount_price * $tax_rate/100;
$sales_total = $discount_price + $tax_amount;

//number formating
$list_price_f = "$".number_format($list_price, 2);
$discount_percent_f = $discount_percent."%";
$discount_f = "$".number_format($discount, 2);
$discount_price_f = "$".number_format($discount_price, 2);
$tax_rate_f = $tax_rate."%";
$tax_amount_f = "$". number_format($tax_amount, 2);
$sales_total_f = "$". number_format($sales_total, 2);

 //checking data
            if (empty($product_description)){
                $errorMsg = "Product can not be blank.";    
            }elseif ( $list_price <= 0) {
                $errorMsg = " Price can not be zero.";
            }elseif (!is_numeric($discount_percent)){
                $errorMsg = "Discount percent must be a valid whole number";
            }else{
                    $errorMsg = '';
                }

            if ($errorMsg != '') {
                include('index.php');
                exit();        
            }  
?>
<!DOCTYPE html>
<html>
<head>
    <title>Product Discount Calculator</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
    <main>
       <h1>Product Discount Calculator</h1>
       
        <label>Product Description:</label>
        <span><?php echo htmlspecialchars($product_description); ?></span><br>

        <label>List Price:</label>
        <span><?php echo htmlspecialchars($list_price_f); ?></span><br>

        <label>Standard Discount:</label>
        <span><?php echo htmlspecialchars($discount_percent_f); ?></span><br>

        <label>Discount Amount:</label>
        <span><?php echo $discount_f; ?></span><br>

        <label>Discount Price:</label>
        <span><?php echo $discount_price_f; ?></span><br>
        <br>
        
        <label>Sales Tax Rate:</label>
        <span><?php echo $tax_rate_f; ?></span><br>
        
        <label>Sales Tax Amount:</label>
        <span><?php echo $tax_amount_f; ?></span><br>
        
        <label>Sales Total:</label>
        <span><?php echo $sales_total_f; ?></span><br>
        
        
        
        
    </main>
</body>
</html>
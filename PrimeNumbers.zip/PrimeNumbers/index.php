<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Prime Numbers</title>
    </head>
    <body>
        <h1>Prime Numbers</h1>
    <?php
        $n = 1000;
        // create the 1000 elements array and initiate it with 1
        $primes = [];
        for ($i = 0; $i <= $n; $i++){
            array_push($primes, '1');
        }
        // set 0 and 1 to 0 
        $primes[0] = '0';
        $primes[1] = '0';
        // run through the array starting from 2 position
        
        for ($i = 2; $i <= sqrt($n); $i++){
            if ($primes[$i] == "1"){
                //checking numbers divisible by itself
                for ($j = $i+1; $j <= $n; $j++){                   
                    if ($j % $i == '0'){
                        $primes[$j] = '0';
                    }
                }
            }
        }      
        // print the result         
        //counter for primes numbers
        $counter = 0;
        for ($i = 0; $i <= $n; $i++){
            if ($primes[$i] == "1"){
                echo "<p style='font-size:15px;>" . $i . " is prime." 
                        ."</p>";
                $counter++;                
                }    
        }
        echo $counter.' prime numbers found.';
    ?>
    </body>
</html>
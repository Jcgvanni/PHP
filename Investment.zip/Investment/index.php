<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <style>
            table tr:nth-child(even) td{
                background-color: white;

            }

            table tr:nth-child(odd) td{
                   background-color: lightblue;
            }
        </style>
        <?php        
        $principal = 1000;
        $rate = 0.05;
        $years;
                // put your code here
        echo "<table border = '1' cellpadding='8'  style = 'background-color:darkblue' width='500px'>";
        echo "<tr> <th style = 'color:#FFFFFF'>Year</th>"
                . " <th style = 'color:#FFFFFF' >Amount on deposit</th></tr> ";
                for ($years = 1; $years <= 10; $years++){
                    $a = $principal * (pow(1 + $rate, $years));
                    $aF = number_format($a, 2);               
                     echo"<tr><td>$years</td>"
                        . " <td>$aF</td></tr>";  
                }                    
        ?>     
    </body>
</html      
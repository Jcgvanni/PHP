<?php
    
    // if an error message exists, go to the index page
    if ($error_message != '') {
        include('index.php');
        exit();
    }

   
   
    
     
    
?>
<!DOCTYPE html>
<html>
<head>
    <title>Future Value Calculator</title>
    <link rel="stylesheet" type="text/css" href="main.css"/>
</head>
<body>
    <main>
        <h1>Future Value Calculator</h1>
        <form action= index.php method="post">
        <label>Investment Amount:</label>
        <span><?php echo htmlspecialchars($investment_f); ?></span><br /> 
           

        <label>Yearly Interest Rate:</label>
        <span><?php echo htmlspecialchars($yearly_rate_f); ?></span><br />  
        

        <label>Number of Years:</label>
        <span><?php echo htmlspecialchars($years); ?></span><br /> 
        

        <label>Future Value:</label>
        <span><?php echo htmlspecialchars($future_value_f); ?></span><br />
        <br>
        
             
        <p>This calculation was done on <?php echo date('m/d/Y'); ?>.</p>
        </form>

      
    </main>
</body>
</html>